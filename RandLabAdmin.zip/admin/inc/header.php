<div class="row header">
	<div class="container">
		<div class="col-lg-12 col-sm-12">
			<div class="col-lg-6 col-sm-6">
				<a href="home.php"><img src="../img/logo.png" class="logo left" alt="" ></a>
			</div>
			<div class="col-lg-6 col-sm-6">
				<a href="index.php" class="right"><h2>Log Out</h2></a>
			</div>
		</div>
	</div>
</div>