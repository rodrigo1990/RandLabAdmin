<script src="../js/jquery.min.js"></script>
<script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
	var $jQuery_1_4_2 = $.noConflict();
</script>

<script type="text/javascript" src="js/jquery.sticky.js"></script>
<script>
	
	 $jQuery_1_4_2(window).load(function(){
      $jQuery_1_4_2(".header").sticky({ topSpacing: 0 });
    });

</script>